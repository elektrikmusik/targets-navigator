import React, { useState, useEffect } from 'react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Textarea } from './components/ui/textarea';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Badge } from './components/ui/badge';
import { toast } from 'sonner@2.0.3';
import { RefreshCw, Save, BarChart3, History, Settings, User, Target } from 'lucide-react';

import { PortfolioDashboard } from './components/PortfolioDashboard';
import { CompanyDetail } from './components/CompanyDetail';

import { projectId, publicAnonKey } from './utils/supabase/info';

interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  maxScore: number;
  color: string;
}

interface Company {
  id: string;
  name: string;
  description: string;
  industry: string;
  strategicFit: number;
  abilityToExecute: number;
  dimensions: Record<string, number>;
  totalScore: number;
  lastUpdated: string;
}

interface ScoreEntry {
  id: string;
  companyId: string;
  userId: string;
  timestamp: string;
  dimensions: Record<string, number>;
  totalScore: number;
  notes?: string;
}

interface AnalyticsData {
  totalEntries: number;
  averageScore: number;
  dimensionAverages: Record<string, number>;
  recentTrend: Array<{ timestamp: string; score: number }>;
  topPerformers: Array<{
    id: string;
    userId: string;
    score: number;
    timestamp: string;
  }>;
}

export default function App() {
  const [dimensions, setDimensions] = useState<ScoreDimension[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [scoreHistory, setScoreHistory] = useState<ScoreEntry[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    totalEntries: 0,
    averageScore: 0,
    dimensionAverages: {},
    recentTrend: [],
    topPerformers: []
  });
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [notes, setNotes] = useState('');
  const [userId, setUserId] = useState('');
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [showDashboard, setShowDashboard] = useState(true);

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-faa13dcb`;

  // Initialize the application
  useEffect(() => {
    initializeApp();
  }, []);

  // Auto-refresh data every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isEditing) {
        loadData();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [isEditing]);

  const initializeApp = async () => {
    try {
      setLoading(true);
      
      // Initialize the scoring framework
      await fetch(`${baseUrl}/init`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
      });

      // Load all data
      await loadData();
    } catch (error) {
      console.error('Error initializing app:', error);
      toast.error('Failed to initialize application');
    } finally {
      setLoading(false);
    }
  };

  const loadData = async () => {
    try {
      // Load dimensions
      const dimensionsResponse = await fetch(`${baseUrl}/dimensions`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      const dimensionsData = await dimensionsResponse.json();
      setDimensions(dimensionsData);

      // Load companies
      const companiesResponse = await fetch(`${baseUrl}/companies`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      const companiesData = await companiesResponse.json();
      setCompanies(companiesData);

      // Load score history
      const historyResponse = await fetch(`${baseUrl}/scores/history`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      const historyData = await historyResponse.json();
      setScoreHistory(historyData);

      // Load analytics
      const analyticsResponse = await fetch(`${baseUrl}/analytics`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      const analyticsData = await analyticsResponse.json();
      setAnalytics(analyticsData);

    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load data');
    }
  };

  const handleScoreUpdate = async (companyId: string, dimensionId: string, score: number) => {
    try {
      const response = await fetch(`${baseUrl}/companies/${companyId}/dimensions/update`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ dimensionId, score }),
      });

      const result = await response.json();
      if (result.success) {
        // Update companies state
        setCompanies(prev => prev.map(comp => 
          comp.id === companyId ? result.company : comp
        ));
        
        // Update selected company if it's the one being edited
        if (selectedCompany?.id === companyId) {
          setSelectedCompany(result.company);
        }
      } else {
        toast.error('Failed to update company dimension score');
      }
    } catch (error) {
      console.error('Error updating company dimension score:', error);
      toast.error('Failed to update company dimension score');
    }
  };

  const handleSubmitScores = async (companyId: string) => {
    try {
      setSubmitting(true);

      const company = companies.find(c => c.id === companyId);
      if (!company) {
        toast.error('Company not found');
        return;
      }

      const response = await fetch(`${baseUrl}/companies/${companyId}/scores/submit`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: userId || 'anonymous',
          dimensions: company.dimensions,
          notes,
        }),
      });

      const result = await response.json();
      if (result.success) {
        toast.success(`Scores submitted for ${company.name}! Total: ${result.totalScore}`);
        setNotes('');
        setIsEditing(false);
        await loadData(); // Refresh data
      } else {
        toast.error('Failed to submit scores');
      }
    } catch (error) {
      console.error('Error submitting scores:', error);
      toast.error('Failed to submit scores');
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = async () => {
    if (!confirm('Are you sure you want to reset all scores? This action cannot be undone.')) {
      return;
    }

    try {
      const response = await fetch(`${baseUrl}/reset`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
      });

      const result = await response.json();
      if (result.success) {
        toast.success('All scores reset successfully');
        await loadData();
      } else {
        toast.error('Failed to reset scores');
      }
    } catch (error) {
      console.error('Error resetting scores:', error);
      toast.error('Failed to reset scores');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 flex items-center justify-center">
        <div className="flex items-center space-x-2">
          <RefreshCw className="h-6 w-6 animate-spin" />
          <span>Initializing Company Portfolio Scoring...</span>
        </div>
      </div>
    );
  }

  const handleCompanySelect = (company: Company) => {
    setSelectedCompany(company);
    setShowDashboard(false);
  };

  const handleBackToPortfolio = () => {
    setSelectedCompany(null);
    setShowDashboard(true);
  };

  const getPortfolioStats = () => {
    if (companies.length === 0) return { totalScore: 0, avgScore: 0, topCompany: null };
    
    const totalScore = companies.reduce((sum, comp) => sum + comp.totalScore, 0);
    const avgScore = totalScore / companies.length;
    const topCompany = companies.reduce((top, comp) => comp.totalScore > top.totalScore ? comp : top);
    
    return { totalScore: Math.round(totalScore), avgScore: Math.round(avgScore * 100) / 100, topCompany };
  };

  const portfolioStats = getPortfolioStats();

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Portfolio Dashboard
            </h1>
            <p className="text-gray-600 mt-1">
              Strategic company evaluation and positioning matrix
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="px-3 py-1">
              {companies.length} Companies
            </Badge>
            <Button
              variant="outline"
              size="sm"
              onClick={loadData}
              className="flex items-center space-x-1"
            >
              <RefreshCw className="h-4 w-4" />
              <span>Refresh</span>
            </Button>
          </div>
        </div>

        {/* Main Content */}
        {showDashboard && !selectedCompany ? (
          // Portfolio Dashboard View
          <PortfolioDashboard
            companies={companies}
            dimensions={dimensions}
            onCompanySelect={handleCompanySelect}
            selectedCompany={selectedCompany}
          />
        ) : (
          // Company Detail View
          selectedCompany && (
            <CompanyDetail
              company={selectedCompany}
              dimensions={dimensions}
              onBack={handleBackToPortfolio}
              onScoreUpdate={handleScoreUpdate}
              isEditing={isEditing}
              onToggleEdit={() => setIsEditing(!isEditing)}
              onSubmitScores={handleSubmitScores}
              submitting={submitting}
            />
          )
        )}
      </div>
    </div>
  );
}
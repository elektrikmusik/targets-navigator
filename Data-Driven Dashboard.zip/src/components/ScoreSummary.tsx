import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { TrendingUp, TrendingDown, Minus, Target, Users, Calendar } from 'lucide-react';

interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  currentScore: number;
  maxScore: number;
  color: string;
}

interface AnalyticsData {
  totalEntries: number;
  averageScore: number;
  dimensionAverages: Record<string, number>;
  recentTrend: Array<{ timestamp: string; score: number }>;
  topPerformers: Array<{
    id: string;
    userId: string;
    score: number;
    timestamp: string;
  }>;
}

interface ScoreSummaryProps {
  dimensions: ScoreDimension[];
  analytics: AnalyticsData;
}

export function ScoreSummary({ dimensions, analytics }: ScoreSummaryProps) {
  // Calculate current total score
  const currentTotal = dimensions.reduce((sum, dim) => 
    sum + (dim.currentScore * dim.weight), 0
  );

  // Determine trend
  const trendDirection = analytics.recentTrend.length >= 2 ? 
    analytics.recentTrend[analytics.recentTrend.length - 1].score - 
    analytics.recentTrend[analytics.recentTrend.length - 2].score : 0;

  const getTrendIcon = () => {
    if (trendDirection > 0) return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (trendDirection < 0) return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-gray-500" />;
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBadge = (score: number) => {
    if (score >= 90) return <Badge variant="default" className="bg-green-500">Excellent</Badge>;
    if (score >= 80) return <Badge variant="default" className="bg-blue-500">Good</Badge>;
    if (score >= 60) return <Badge variant="default" className="bg-yellow-500">Fair</Badge>;
    return <Badge variant="destructive">Needs Improvement</Badge>;
  };

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Current Total Score</CardTitle>
          <Target className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <div className={`text-2xl font-bold ${getScoreColor(currentTotal)}`}>
              {Math.round(currentTotal * 100) / 100}
            </div>
            <div className="flex items-center space-x-1">
              {getTrendIcon()}
              {trendDirection !== 0 && (
                <span className="text-sm text-muted-foreground">
                  {Math.abs(Math.round(trendDirection * 100) / 100)}
                </span>
              )}
            </div>
          </div>
          <div className="mt-2">
            {getScoreBadge(currentTotal)}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Average Score</CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className={`text-2xl font-bold ${getScoreColor(analytics.averageScore)}`}>
            {analytics.averageScore}
          </div>
          <p className="text-xs text-muted-foreground">
            Based on {analytics.totalEntries} entries
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Top Dimension</CardTitle>
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {(() => {
            const topDimension = dimensions.reduce((max, dim) => 
              dim.currentScore > max.currentScore ? dim : max
            );
            return (
              <>
                <div className="text-2xl font-bold" style={{ color: topDimension.color }}>
                  {topDimension.name}
                </div>
                <p className="text-xs text-muted-foreground">
                  Score: {topDimension.currentScore}
                </p>
              </>
            );
          })()}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Latest Entry</CardTitle>
          <Calendar className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {analytics.topPerformers.length > 0 ? (
            <>
              <div className="text-2xl font-bold">
                {analytics.topPerformers[0].score}
              </div>
              <p className="text-xs text-muted-foreground">
                {new Date(analytics.topPerformers[0].timestamp).toLocaleDateString()}
              </p>
            </>
          ) : (
            <>
              <div className="text-2xl font-bold text-muted-foreground">-</div>
              <p className="text-xs text-muted-foreground">No entries yet</p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
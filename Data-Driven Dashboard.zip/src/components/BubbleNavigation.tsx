import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { motion } from 'motion/react';

interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  currentScore: number;
  maxScore: number;
  color: string;
}

interface BubbleData extends ScoreDimension {
  x: number;
  y: number;
  radius: number;
}

interface BubbleNavigationProps {
  dimensions: ScoreDimension[];
  onDimensionSelect: (dimension: ScoreDimension) => void;
  selectedDimension?: ScoreDimension | null;
}

export function BubbleNavigation({ dimensions, onDimensionSelect, selectedDimension }: BubbleNavigationProps) {
  const [bubbles, setBubbles] = useState<BubbleData[]>([]);
  const [hoveredBubble, setHoveredBubble] = useState<string | null>(null);

  const svgWidth = 600;
  const svgHeight = 400;
  const centerX = svgWidth / 2;
  const centerY = svgHeight / 2;

  // Calculate bubble positions and sizes
  useEffect(() => {
    if (dimensions.length === 0) return;

    const bubbleData: BubbleData[] = dimensions.map((dim, index) => {
      // Calculate radius based on score (min 30, max 80)
      const scoreRatio = dim.currentScore / dim.maxScore;
      const radius = 30 + (scoreRatio * 50);

      // Position bubbles in a circle around the center
      const angle = (index / dimensions.length) * 2 * Math.PI;
      const orbitRadius = 120;
      const x = centerX + Math.cos(angle) * orbitRadius;
      const y = centerY + Math.sin(angle) * orbitRadius;

      return {
        ...dim,
        x,
        y,
        radius
      };
    });

    setBubbles(bubbleData);
  }, [dimensions]);

  const handleBubbleClick = (bubble: BubbleData) => {
    onDimensionSelect(bubble);
  };

  const getTotalScore = () => {
    return dimensions.reduce((sum, dim) => sum + (dim.currentScore * dim.weight), 0);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>7-Dimensional Navigation</CardTitle>
          <Badge variant="outline" className="px-3 py-1">
            Total: {Math.round(getTotalScore() * 100) / 100}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Click on any dimension bubble to explore details. Bubble size reflects current score.
        </p>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col lg:flex-row items-center gap-6">
          {/* SVG Bubble Chart */}
          <div className="relative">
            <svg
              width={svgWidth}
              height={svgHeight}
              className="border rounded-lg bg-gradient-to-br from-purple-50/50 to-blue-50/50"
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            >
              {/* Central circle */}
              <motion.circle
                cx={centerX}
                cy={centerY}
                r="25"
                fill="url(#centralGradient)"
                stroke="#8B5CF6"
                strokeWidth="2"
                className="drop-shadow-sm cursor-pointer"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.8, type: "spring" }}
                whileHover={{ scale: 1.1 }}
              />
              <motion.text
                x={centerX}
                y={centerY - 5}
                textAnchor="middle"
                className="text-xs font-medium fill-white pointer-events-none"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
              >
                7D
              </motion.text>
              <motion.text
                x={centerX}
                y={centerY + 8}
                textAnchor="middle"
                className="text-xs font-medium fill-white pointer-events-none"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
              >
                {Math.round(getTotalScore())}
              </motion.text>

              {/* Connection lines */}
              {bubbles.map((bubble) => (
                <motion.line
                  key={`line-${bubble.id}`}
                  x1={centerX}
                  y1={centerY}
                  x2={bubble.x}
                  y2={bubble.y}
                  stroke="#E5E7EB"
                  strokeWidth="1"
                  strokeDasharray="3,3"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 1, delay: 0.5 }}
                />
              ))}

              {/* Dimension bubbles */}
              {bubbles.map((bubble, index) => (
                <g key={bubble.id}>
                  <motion.circle
                    cx={bubble.x}
                    cy={bubble.y}
                    r={bubble.radius}
                    fill={`url(#gradient-${bubble.id})`}
                    fillOpacity={
                      selectedDimension?.id === bubble.id ? 0.9 :
                      hoveredBubble === bubble.id ? 0.8 : 0.6
                    }
                    stroke={selectedDimension?.id === bubble.id ? "#374151" : bubble.color}
                    strokeWidth={selectedDimension?.id === bubble.id ? "3" : "2"}
                    className="cursor-pointer transition-all duration-200 drop-shadow-md"
                    onClick={() => handleBubbleClick(bubble)}
                    onMouseEnter={() => setHoveredBubble(bubble.id)}
                    onMouseLeave={() => setHoveredBubble(null)}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1, type: "spring" }}
                    whileHover={{ 
                      scale: 1.1,
                      transition: { duration: 0.2 }
                    }}
                    whileTap={{ scale: 0.95 }}
                  />
                  
                  {/* Glow effect for high-scoring dimensions */}
                  {bubble.currentScore >= 80 && (
                    <motion.circle
                      cx={bubble.x}
                      cy={bubble.y}
                      r={bubble.radius + 8}
                      fill="none"
                      stroke={bubble.color}
                      strokeWidth="2"
                      strokeOpacity="0.4"
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ 
                        scale: [0.8, 1.1, 0.8],
                        opacity: [0, 0.6, 0]
                      }}
                      transition={{ 
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut",
                        delay: index * 0.3
                      }}
                    />
                  )}
                  
                  {/* Bubble label */}
                  <motion.text
                    x={bubble.x}
                    y={bubble.y - 5}
                    textAnchor="middle"
                    className="text-xs font-medium fill-white pointer-events-none"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
                  >
                    {bubble.name}
                  </motion.text>
                  
                  {/* Score label */}
                  <motion.text
                    x={bubble.x}
                    y={bubble.y + 8}
                    textAnchor="middle"
                    className="text-xs font-bold fill-white pointer-events-none"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 + 0.4 }}
                  >
                    {bubble.currentScore}
                  </motion.text>
                </g>
              ))}

              {/* Pulse rings for central circle */}
              <motion.circle
                cx={centerX}
                cy={centerY}
                r="35"
                fill="none"
                stroke="#8B5CF6"
                strokeWidth="1"
                strokeOpacity="0.3"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ 
                  scale: [0.8, 1.2, 0.8],
                  opacity: [0, 0.5, 0]
                }}
                transition={{ 
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
              <motion.circle
                cx={centerX}
                cy={centerY}
                r="45"
                fill="none"
                stroke="#06B6D4"
                strokeWidth="1"
                strokeOpacity="0.2"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ 
                  scale: [0.8, 1.4, 0.8],
                  opacity: [0, 0.3, 0]
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 1
                }}
              />

              {/* Gradient definitions */}
              <defs>
                <linearGradient id="centralGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#8B5CF6" />
                  <stop offset="100%" stopColor="#06B6D4" />
                </linearGradient>
                {bubbles.map((bubble) => (
                  <linearGradient key={`grad-${bubble.id}`} id={`gradient-${bubble.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor={bubble.color} />
                    <stop offset="100%" stopColor={bubble.color} stopOpacity="0.8" />
                  </linearGradient>
                ))}
              </defs>
            </svg>

            {/* Hover tooltip */}
            {hoveredBubble && (
              <motion.div
                className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-lg border max-w-48"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.2 }}
              >
                {(() => {
                  const bubble = bubbles.find(b => b.id === hoveredBubble);
                  if (!bubble) return null;
                  return (
                    <div>
                      <div className="font-medium text-sm" style={{ color: bubble.color }}>
                        {bubble.name}
                      </div>
                      <div className="text-xs text-muted-foreground mb-2">
                        {bubble.description}
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Score:</span>
                        <span className="font-medium">{bubble.currentScore}/{bubble.maxScore}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Weight:</span>
                        <span className="font-medium">{Math.round(bubble.weight * 100)}%</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Weighted:</span>
                        <span className="font-medium" style={{ color: bubble.color }}>
                          {Math.round(bubble.currentScore * bubble.weight * 100) / 100}
                        </span>
                      </div>
                    </div>
                  );
                })()}
              </motion.div>
            )}
          </div>

          {/* Legend */}
          <div className="space-y-4 min-w-64">
            <h4 className="font-medium">Dimensions Overview</h4>
            <div className="space-y-2">
              {bubbles.map((bubble) => (
                <motion.div
                  key={bubble.id}
                  className={`flex items-center justify-between p-2 rounded-lg border cursor-pointer transition-all ${
                    selectedDimension?.id === bubble.id 
                      ? 'bg-primary/5 border-primary' 
                      : 'hover:bg-muted/50'
                  }`}
                  onClick={() => handleBubbleClick(bubble)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center space-x-3">
                    <div
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: bubble.color }}
                    />
                    <div>
                      <div className="text-sm font-medium">{bubble.name}</div>
                      <div className="text-xs text-muted-foreground">
                        Weight: {Math.round(bubble.weight * 100)}%
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">{bubble.currentScore}</div>
                    <div className="text-xs text-muted-foreground">
                      /{bubble.maxScore}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
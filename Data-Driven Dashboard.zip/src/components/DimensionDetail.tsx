import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Slider } from './ui/slider';
import { Textarea } from './ui/textarea';
import { ArrowLeft, TrendingUp, TrendingDown, Target, Award, Lightbulb } from 'lucide-react';
import { motion } from 'motion/react';

interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  currentScore: number;
  maxScore: number;
  color: string;
}

interface DimensionDetailProps {
  dimension: ScoreDimension;
  onBack: () => void;
  onScoreUpdate: (dimensionId: string, score: number) => void;
  isEditing: boolean;
  onToggleEdit: () => void;
  averageScore?: number;
}

export function DimensionDetail({ 
  dimension, 
  onBack, 
  onScoreUpdate, 
  isEditing, 
  onToggleEdit,
  averageScore = 0 
}: DimensionDetailProps) {
  const [tempScore, setTempScore] = useState(dimension.currentScore);
  const [notes, setNotes] = useState('');

  const percentage = (dimension.currentScore / dimension.maxScore) * 100;
  const weightedScore = dimension.currentScore * dimension.weight;
  const isAboveAverage = dimension.currentScore > averageScore;

  const handleSliderChange = (value: number[]) => {
    setTempScore(value[0]);
    onScoreUpdate(dimension.id, value[0]);
  };

  const getScoreGrade = (score: number) => {
    if (score >= 90) return { grade: 'A+', color: 'text-green-600', icon: Award };
    if (score >= 80) return { grade: 'A', color: 'text-green-500', icon: Award };
    if (score >= 70) return { grade: 'B', color: 'text-blue-500', icon: Target };
    if (score >= 60) return { grade: 'C', color: 'text-yellow-500', icon: Target };
    return { grade: 'D', color: 'text-red-500', icon: TrendingDown };
  };

  const scoreGrade = getScoreGrade(dimension.currentScore);
  const ScoreIcon = scoreGrade.icon;

  const getDimensionInsights = () => {
    const insights = [];
    
    if (dimension.currentScore >= 85) {
      insights.push("Excellent performance in this dimension!");
    } else if (dimension.currentScore >= 70) {
      insights.push("Good performance, room for improvement.");
    } else if (dimension.currentScore >= 50) {
      insights.push("Average performance, consider focusing on this area.");
    } else {
      insights.push("This dimension needs significant attention.");
    }

    if (dimension.weight > 0.15) {
      insights.push("High-impact dimension with significant weight.");
    }

    if (isAboveAverage) {
      insights.push("Above average compared to other dimensions.");
    } else {
      insights.push("Below average compared to other dimensions.");
    }

    return insights;
  };

  const getImprovementSuggestions = () => {
    const suggestions: Record<string, string[]> = {
      innovation: [
        "Explore new technologies and methodologies",
        "Encourage creative problem-solving sessions",
        "Attend innovation workshops and conferences"
      ],
      execution: [
        "Implement better project management practices",
        "Focus on quality assurance processes",
        "Improve delivery timelines and milestones"
      ],
      impact: [
        "Measure and track key performance indicators",
        "Gather user feedback and testimonials",
        "Document and showcase measurable results"
      ],
      scalability: [
        "Design systems with growth in mind",
        "Plan for increased user loads",
        "Consider automation opportunities"
      ],
      sustainability: [
        "Focus on long-term viability",
        "Implement sustainable practices",
        "Plan for future maintenance and updates"
      ],
      collaboration: [
        "Improve communication channels",
        "Foster team building activities",
        "Implement collaborative tools and practices"
      ],
      learning: [
        "Invest in continuous education",
        "Document lessons learned",
        "Share knowledge with team members"
      ]
    };

    return suggestions[dimension.id] || [
      "Set specific goals for improvement",
      "Regular review and assessment",
      "Seek feedback from peers and mentors"
    ];
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack} className="flex items-center space-x-2">
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Navigation</span>
        </Button>
        <Button
          variant={isEditing ? "destructive" : "default"}
          onClick={onToggleEdit}
        >
          {isEditing ? 'Cancel Edit' : 'Edit Score'}
        </Button>
      </div>

      {/* Dimension Header Card */}
      <Card className="relative overflow-hidden">
        <div 
          className="absolute top-0 left-0 w-full h-2"
          style={{ backgroundColor: dimension.color }}
        />
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <div className="flex items-center space-x-3">
                <CardTitle className="text-2xl">{dimension.name}</CardTitle>
                <Badge 
                  variant="secondary" 
                  className="text-sm"
                  style={{ backgroundColor: `${dimension.color}20`, color: dimension.color }}
                >
                  Weight: {Math.round(dimension.weight * 100)}%
                </Badge>
              </div>
              <p className="text-muted-foreground">{dimension.description}</p>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-2">
                <ScoreIcon className={`h-6 w-6 ${scoreGrade.color}`} />
                <span className={`text-2xl font-bold ${scoreGrade.color}`}>
                  {scoreGrade.grade}
                </span>
              </div>
              <div className="text-sm text-muted-foreground mt-1">
                {dimension.currentScore}/{dimension.maxScore}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Score Details */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Current Score Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="h-5 w-5" />
              <span>Current Score</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{Math.round(percentage)}%</span>
              </div>
              <Progress 
                value={percentage} 
                className="h-3"
                style={{
                  background: `linear-gradient(to right, ${dimension.color}22 0%, ${dimension.color}22 ${percentage}%, #e2e8f0 ${percentage}%, #e2e8f0 100%)`
                }}
              />
            </div>

            {isEditing && (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Adjust Score:</span>
                  <span className="font-bold" style={{ color: dimension.color }}>
                    {tempScore}
                  </span>
                </div>
                <Slider
                  value={[tempScore]}
                  onValueChange={handleSliderChange}
                  max={dimension.maxScore}
                  min={0}
                  step={1}
                  className="w-full"
                />
              </div>
            )}

            <div className="space-y-2 pt-2 border-t">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Raw Score</span>
                <span className="font-medium">{dimension.currentScore}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Weighted Score</span>
                <span className="font-bold" style={{ color: dimension.color }}>
                  {Math.round(weightedScore * 100) / 100}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">vs Average</span>
                <div className="flex items-center space-x-1">
                  {isAboveAverage ? (
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-500" />
                  )}
                  <span className={isAboveAverage ? 'text-green-500' : 'text-red-500'}>
                    {isAboveAverage ? '+' : ''}{Math.round((dimension.currentScore - averageScore) * 100) / 100}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Insights Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Lightbulb className="h-5 w-5" />
              <span>Insights</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {getDimensionInsights().map((insight, index) => (
                <div key={index} className="flex items-start space-x-2">
                  <div 
                    className="w-2 h-2 rounded-full mt-2 flex-shrink-0"
                    style={{ backgroundColor: dimension.color }}
                  />
                  <p className="text-sm text-muted-foreground">{insight}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Improvement Suggestions */}
      <Card>
        <CardHeader>
          <CardTitle>Improvement Suggestions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {getImprovementSuggestions().map((suggestion, index) => (
              <motion.div
                key={index}
                className="p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                whileHover={{ scale: 1.02 }}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <p className="text-sm">{suggestion}</p>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Notes Section */}
      {isEditing && (
        <Card>
          <CardHeader>
            <CardTitle>Notes & Comments</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder={`Add notes about ${dimension.name} performance...`}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}
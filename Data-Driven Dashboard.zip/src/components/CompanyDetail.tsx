import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Slider } from './ui/slider';
import { Textarea } from './ui/textarea';
import { ArrowLeft, Building2, TrendingUp, Target, Award, Lightbulb, MapPin } from 'lucide-react';
import { motion } from 'motion/react';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from 'recharts';

interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  maxScore: number;
  color: string;
}

interface Company {
  id: string;
  name: string;
  description: string;
  industry: string;
  strategicFit: number;
  abilityToExecute: number;
  dimensions: Record<string, number>;
  totalScore: number;
  lastUpdated: string;
}

interface CompanyDetailProps {
  company: Company;
  dimensions: ScoreDimension[];
  onBack: () => void;
  onScoreUpdate: (companyId: string, dimensionId: string, score: number) => void;
  isEditing: boolean;
  onToggleEdit: () => void;
  onSubmitScores: (companyId: string) => void;
  submitting: boolean;
}

export function CompanyDetail({ 
  company, 
  dimensions,
  onBack, 
  onScoreUpdate, 
  isEditing, 
  onToggleEdit,
  onSubmitScores,
  submitting
}: CompanyDetailProps) {
  const [notes, setNotes] = useState('');

  const getIndustryColor = (industry: string) => {
    const colors: Record<string, string> = {
      'Technology': '#8B5CF6',
      'Energy': '#10B981',
      'Healthcare': '#06B6D4',
      'Fintech': '#F59E0B',
      'Logistics': '#EC4899',
      'Manufacturing': '#EF4444',
      'Retail': '#84CC16',
      'Default': '#6B7280'
    };
    return colors[industry] || colors.Default;
  };

  const handleSliderChange = (dimensionId: string, value: number[]) => {
    onScoreUpdate(company.id, dimensionId, value[0]);
  };

  const getScoreGrade = (score: number) => {
    if (score >= 90) return { grade: 'A+', color: 'text-green-600', icon: Award };
    if (score >= 80) return { grade: 'A', color: 'text-green-500', icon: Award };
    if (score >= 70) return { grade: 'B', color: 'text-blue-500', icon: Target };
    if (score >= 60) return { grade: 'C', color: 'text-yellow-500', icon: Target };
    return { grade: 'D', color: 'text-red-500', icon: TrendingUp };
  };

  const scoreGrade = getScoreGrade(company.totalScore);
  const ScoreIcon = scoreGrade.icon;

  // Prepare radar chart data
  const radarData = dimensions.map(dim => ({
    dimension: dim.name.replace(' ', '\n'),
    score: company.dimensions[dim.id] || 0,
    fullMark: dim.maxScore
  }));

  const getQuadrantPosition = () => {
    if (company.strategicFit > 5 && company.abilityToExecute > 5) {
      return { label: 'Priority Leads / Investigate now', color: '#10B981', bg: 'bg-green-50' };
    } else if (company.strategicFit <= 5 && company.abilityToExecute > 5) {
      return { label: 'Monitor / Opportunistic', color: '#6B7280', bg: 'bg-gray-50' };
    } else if (company.strategicFit <= 5 && company.abilityToExecute <= 5) {
      return { label: 'Not a focus', color: '#EF4444', bg: 'bg-red-50' };
    } else {
      return { label: 'Nurture with Support', color: '#F59E0B', bg: 'bg-yellow-50' };
    }
  };

  const quadrant = getQuadrantPosition();

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack} className="flex items-center space-x-2">
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Portfolio</span>
        </Button>
        <div className="flex items-center space-x-2">
          <Button
            variant={isEditing ? "destructive" : "default"}
            onClick={onToggleEdit}
          >
            {isEditing ? 'Cancel Edit' : 'Edit Scores'}
          </Button>
          {isEditing && (
            <Button 
              onClick={() => onSubmitScores(company.id)} 
              disabled={submitting}
              className="flex items-center space-x-2"
            >
              <Target className="h-4 w-4" />
              <span>{submitting ? 'Submitting...' : 'Submit Scores'}</span>
            </Button>
          )}
        </div>
      </div>

      {/* Company Header Card */}
      <Card className="relative overflow-hidden">
        <div 
          className="absolute top-0 left-0 w-full h-2"
          style={{ backgroundColor: getIndustryColor(company.industry) }}
        />
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Building2 className="h-8 w-8" style={{ color: getIndustryColor(company.industry) }} />
                <div>
                  <CardTitle className="text-2xl">{company.name}</CardTitle>
                  <p className="text-muted-foreground">{company.description}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <Badge 
                  variant="secondary" 
                  className="text-sm"
                  style={{ backgroundColor: `${getIndustryColor(company.industry)}20`, color: getIndustryColor(company.industry) }}
                >
                  {company.industry}
                </Badge>
                <Badge 
                  variant="outline" 
                  className={`text-sm ${quadrant.bg}`}
                  style={{ color: quadrant.color, borderColor: quadrant.color }}
                >
                  {quadrant.label}
                </Badge>
              </div>
            </div>
            
            <div className="text-right space-y-2">
              <div className="flex items-center space-x-2">
                <ScoreIcon className={`h-6 w-6 ${scoreGrade.color}`} />
                <span className={`text-2xl font-bold ${scoreGrade.color}`}>
                  {scoreGrade.grade}
                </span>
              </div>
              <div className="text-sm text-muted-foreground">
                Total: {Math.round(company.totalScore * 100) / 100}
              </div>
              <div className="text-xs text-muted-foreground">
                Updated: {new Date(company.lastUpdated).toLocaleDateString()}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Strategic Position & Radar Chart */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Strategic Position */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MapPin className="h-5 w-5" />
              <span>Strategic Position</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Strategic Fit</span>
                  <span className="font-bold">{company.strategicFit}/10</span>
                </div>
                <Progress 
                  value={(company.strategicFit / 10) * 100} 
                  className="h-3"
                />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Ability to Execute</span>
                  <span className="font-bold">{company.abilityToExecute}/10</span>
                </div>
                <Progress 
                  value={(company.abilityToExecute / 10) * 100} 
                  className="h-3"
                />
              </div>
            </div>

            <div className={`p-4 rounded-lg ${quadrant.bg} border`}>
              <div className="text-sm font-medium" style={{ color: quadrant.color }}>
                Portfolio Quadrant
              </div>
              <div className="text-lg font-bold mt-1" style={{ color: quadrant.color }}>
                {quadrant.label}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Radar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>6-Dimension Score Profile</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData}>
                  <PolarGrid />
                  <PolarAngleAxis 
                    dataKey="dimension" 
                    tick={{ fontSize: 11 }}
                    className="text-xs"
                  />
                  <PolarRadiusAxis 
                    angle={90} 
                    domain={[0, 100]}
                    tick={{ fontSize: 10 }}
                  />
                  <Radar
                    name="Score"
                    dataKey="score"
                    stroke={getIndustryColor(company.industry)}
                    fill={getIndustryColor(company.industry)}
                    fillOpacity={0.3}
                    strokeWidth={2}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Dimension Details */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Dimension Scores</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {dimensions.map((dimension) => {
              const score = company.dimensions[dimension.id] || 0;
              const percentage = (score / dimension.maxScore) * 100;
              const weightedScore = score * dimension.weight;

              return (
                <motion.div
                  key={dimension.id}
                  className="p-4 border rounded-lg space-y-3"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm" style={{ color: dimension.color }}>
                        {dimension.name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Weight: {Math.round(dimension.weight * 100)}%
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold" style={{ color: dimension.color }}>
                        {score}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        /{dimension.maxScore}
                      </div>
                    </div>
                  </div>

                  <Progress 
                    value={percentage} 
                    className="h-2"
                    style={{
                      background: `linear-gradient(to right, ${dimension.color}22 0%, ${dimension.color}22 ${percentage}%, #e2e8f0 ${percentage}%, #e2e8f0 100%)`
                    }}
                  />

                  {isEditing && (
                    <div className="space-y-2">
                      <Slider
                        value={[score]}
                        onValueChange={(value) => handleSliderChange(dimension.id, value)}
                        max={dimension.maxScore}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>
                  )}

                  <div className="text-xs text-muted-foreground">
                    {dimension.description}
                  </div>

                  <div className="pt-2 border-t">
                    <div className="flex justify-between">
                      <span className="text-xs text-muted-foreground">Weighted</span>
                      <span className="text-xs font-bold" style={{ color: dimension.color }}>
                        {Math.round(weightedScore * 100) / 100}
                      </span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Notes Section */}
      {isEditing && (
        <Card>
          <CardHeader>
            <CardTitle>Scoring Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder={`Add notes about ${company.name} scoring evaluation...`}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </CardContent>
        </Card>
      )}

      {/* Company Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Lightbulb className="h-5 w-5" />
            <span>Strategic Insights</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <h4 className="font-medium">Strengths</h4>
              {dimensions
                .filter(d => company.dimensions[d.id] >= 75)
                .map((dimension) => (
                  <div key={dimension.id} className="flex items-center space-x-2">
                    <div 
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: dimension.color }}
                    />
                    <span className="text-sm">{dimension.name} ({company.dimensions[dimension.id]})</span>
                  </div>
                ))}
              {dimensions.filter(d => company.dimensions[d.id] >= 75).length === 0 && (
                <p className="text-sm text-muted-foreground">No strong dimensions identified yet.</p>
              )}
            </div>

            <div className="space-y-3">
              <h4 className="font-medium">Areas for Improvement</h4>
              {dimensions
                .filter(d => company.dimensions[d.id] < 60)
                .map((dimension) => (
                  <div key={dimension.id} className="flex items-center space-x-2">
                    <div 
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: dimension.color }}
                    />
                    <span className="text-sm">{dimension.name} ({company.dimensions[dimension.id]})</span>
                  </div>
                ))}
              {dimensions.filter(d => company.dimensions[d.id] < 60).length === 0 && (
                <p className="text-sm text-muted-foreground">All dimensions performing well.</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
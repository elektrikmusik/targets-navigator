import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { ScrollArea } from './ui/scroll-area';

interface ScoreEntry {
  id: string;
  userId: string;
  timestamp: string;
  dimensions: Record<string, number>;
  totalScore: number;
  notes?: string;
}

interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  currentScore: number;
  maxScore: number;
  color: string;
}

interface ScoreHistoryProps {
  scoreHistory: ScoreEntry[];
  dimensions: ScoreDimension[];
}

export function ScoreHistory({ scoreHistory, dimensions }: ScoreHistoryProps) {
  const getScoreBadge = (score: number) => {
    if (score >= 90) return <Badge variant="default" className="bg-green-500">Excellent</Badge>;
    if (score >= 80) return <Badge variant="default" className="bg-blue-500">Good</Badge>;
    if (score >= 60) return <Badge variant="default" className="bg-yellow-500">Fair</Badge>;
    return <Badge variant="destructive">Poor</Badge>;
  };

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  const getTopDimensionForEntry = (entry: ScoreEntry) => {
    let topDimension = '';
    let topScore = 0;
    
    Object.entries(entry.dimensions).forEach(([dimId, score]) => {
      if (score > topScore) {
        topScore = score;
        const dimension = dimensions.find(d => d.id === dimId);
        topDimension = dimension?.name || dimId;
      }
    });
    
    return { name: topDimension, score: topScore };
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Score History
          <Badge variant="outline">{scoreHistory.length} entries</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {scoreHistory.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>No score entries yet.</p>
            <p className="text-sm">Start by updating dimension scores and submitting your first entry!</p>
          </div>
        ) : (
          <ScrollArea className="h-96">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Total Score</TableHead>
                  <TableHead>Grade</TableHead>
                  <TableHead>Top Dimension</TableHead>
                  <TableHead>User ID</TableHead>
                  <TableHead>Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {scoreHistory.map((entry) => {
                  const topDimension = getTopDimensionForEntry(entry);
                  return (
                    <TableRow key={entry.id}>
                      <TableCell className="font-medium">
                        {formatDate(entry.timestamp)}
                      </TableCell>
                      <TableCell>
                        <span className="font-bold text-lg">
                          {entry.totalScore}
                        </span>
                      </TableCell>
                      <TableCell>
                        {getScoreBadge(entry.totalScore)}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">{topDimension.name}</span>
                          <span className="text-sm text-muted-foreground">
                            {topDimension.score}/100
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {entry.userId || 'anonymous'}
                      </TableCell>
                      <TableCell className="max-w-40">
                        {entry.notes ? (
                          <span className="text-sm truncate block" title={entry.notes}>
                            {entry.notes}
                          </span>
                        ) : (
                          <span className="text-sm text-muted-foreground">-</span>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
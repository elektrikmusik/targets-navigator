import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Button } from './ui/button';
import { Slider } from './ui/slider';

interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  currentScore: number;
  maxScore: number;
  color: string;
}

interface DimensionCardProps {
  dimension: ScoreDimension;
  onScoreUpdate: (dimensionId: string, score: number) => void;
  isEditing: boolean;
}

export function DimensionCard({ dimension, onScoreUpdate, isEditing }: DimensionCardProps) {
  const percentage = (dimension.currentScore / dimension.maxScore) * 100;
  const weightedScore = dimension.currentScore * dimension.weight;

  const handleSliderChange = (value: number[]) => {
    onScoreUpdate(dimension.id, value[0]);
  };

  return (
    <Card className="relative overflow-hidden">
      <div 
        className="absolute top-0 left-0 w-1 h-full"
        style={{ backgroundColor: dimension.color }}
      />
      
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{dimension.name}</CardTitle>
          <div className="text-sm text-muted-foreground">
            Weight: {Math.round(dimension.weight * 100)}%
          </div>
        </div>
        <p className="text-sm text-muted-foreground">{dimension.description}</p>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between text-sm">
          <span>Score</span>
          <span className="font-bold">
            {dimension.currentScore} / {dimension.maxScore}
          </span>
        </div>
        
        <Progress 
          value={percentage} 
          className="h-2"
          style={{
            background: `linear-gradient(to right, ${dimension.color}22 0%, ${dimension.color}22 ${percentage}%, #e2e8f0 ${percentage}%, #e2e8f0 100%)`
          }}
        />
        
        {isEditing && (
          <div className="space-y-2">
            <Slider
              value={[dimension.currentScore]}
              onValueChange={handleSliderChange}
              max={dimension.maxScore}
              min={0}
              step={1}
              className="w-full"
            />
          </div>
        )}
        
        <div className="pt-2 border-t">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Weighted Score</span>
            <span className="font-bold text-lg" style={{ color: dimension.color }}>
              {Math.round(weightedScore * 100) / 100}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
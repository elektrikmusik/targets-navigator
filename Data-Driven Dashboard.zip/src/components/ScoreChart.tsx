import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, BarChart, Bar } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  currentScore: number;
  maxScore: number;
  color: string;
}

interface ScoreEntry {
  id: string;
  userId: string;
  timestamp: string;
  dimensions: Record<string, number>;
  totalScore: number;
  notes?: string;
}

interface ScoreChartProps {
  dimensions: ScoreDimension[];
  scoreHistory: ScoreEntry[];
  recentTrend: Array<{ timestamp: string; score: number }>;
}

export function ScoreChart({ dimensions, scoreHistory, recentTrend }: ScoreChartProps) {
  // Prepare data for radar chart
  const radarData = dimensions.map(dim => ({
    dimension: dim.name,
    score: dim.currentScore,
    maxScore: dim.maxScore,
    fullMark: dim.maxScore
  }));

  // Prepare data for dimension comparison bar chart
  const barData = dimensions.map(dim => ({
    name: dim.name.slice(0, 10) + (dim.name.length > 10 ? '...' : ''),
    score: dim.currentScore,
    weighted: Math.round(dim.currentScore * dim.weight * 100) / 100,
    color: dim.color
  }));

  // Prepare trend data with formatted dates
  const trendData = recentTrend.map((entry, index) => ({
    ...entry,
    date: new Date(entry.timestamp).toLocaleDateString(),
    index: index + 1
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle>Score Visualization</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="radar" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="radar">Radar Chart</TabsTrigger>
            <TabsTrigger value="bars">Dimensions</TabsTrigger>
            <TabsTrigger value="trend">Trend</TabsTrigger>
          </TabsList>
          
          <TabsContent value="radar" className="mt-6">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData}>
                  <PolarGrid />
                  <PolarAngleAxis 
                    dataKey="dimension" 
                    tick={{ fontSize: 12 }}
                    className="text-sm"
                  />
                  <PolarRadiusAxis 
                    angle={90} 
                    domain={[0, 100]}
                    tick={{ fontSize: 10 }}
                  />
                  <Radar
                    name="Current Score"
                    dataKey="score"
                    stroke="#8B5CF6"
                    fill="#8B5CF6"
                    fillOpacity={0.3}
                    strokeWidth={2}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          <TabsContent value="bars" className="mt-6">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fontSize: 12 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    formatter={(value, name) => [
                      `${value}${name === 'weighted' ? ' (weighted)' : ''}`, 
                      name === 'score' ? 'Raw Score' : 'Weighted Score'
                    ]}
                  />
                  <Bar dataKey="score" fill="#06B6D4" name="score" />
                  <Bar dataKey="weighted" fill="#10B981" name="weighted" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          <TabsContent value="trend" className="mt-6">
            <div className="h-80">
              {trendData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip 
                      labelFormatter={(label) => `Date: ${label}`}
                      formatter={(value) => [`${value}`, 'Total Score']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="score" 
                      stroke="#8B5CF6" 
                      strokeWidth={3}
                      dot={{ r: 6, fill: '#8B5CF6' }}
                      activeDot={{ r: 8 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  No trend data available yet. Submit some scores to see the trend!
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
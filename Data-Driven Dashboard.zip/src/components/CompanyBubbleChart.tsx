import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { motion } from 'motion/react';
import exampleImage from 'figma:asset/f0d2458fe7a48230edb842d4d72a43582a91a61f.png';

interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  maxScore: number;
  color: string;
}

interface Company {
  id: string;
  name: string;
  description: string;
  industry: string;
  strategicFit: number; // 0-10 scale
  abilityToExecute: number; // 0-10 scale
  dimensions: Record<string, number>;
  totalScore: number;
  lastUpdated: string;
}

interface CompanyBubbleData extends Company {
  x: number;
  y: number;
  radius: number;
}

interface CompanyBubbleChartProps {
  companies: Company[];
  dimensions: ScoreDimension[];
  onCompanySelect: (company: Company) => void;
  selectedCompany?: Company | null;
}

export function CompanyBubbleChart({ companies, dimensions, onCompanySelect, selectedCompany }: CompanyBubbleChartProps) {
  const [bubbles, setBubbles] = useState<CompanyBubbleData[]>([]);
  const [hoveredBubble, setHoveredBubble] = useState<string | null>(null);

  const svgWidth = 800;
  const svgHeight = 600;
  const padding = 80;
  const chartWidth = svgWidth - 2 * padding;
  const chartHeight = svgHeight - 2 * padding;

  // Calculate bubble positions and sizes
  useEffect(() => {
    if (companies.length === 0) return;

    const bubbleData: CompanyBubbleData[] = companies.map((company) => {
      // Map strategic fit (0-10) to x position
      const x = padding + (company.strategicFit / 10) * chartWidth;
      
      // Map ability to execute (0-10) to y position (inverted for SVG coordinates)
      const y = padding + chartHeight - (company.abilityToExecute / 10) * chartHeight;
      
      // Calculate radius based on total score (min 15, max 35)
      const scoreRatio = company.totalScore / 100;
      const radius = 15 + (scoreRatio * 20);

      return {
        ...company,
        x,
        y,
        radius
      };
    });

    setBubbles(bubbleData);
  }, [companies]);

  const handleBubbleClick = (bubble: CompanyBubbleData) => {
    onCompanySelect(bubble);
  };

  const getIndustryColor = (industry: string) => {
    const colors: Record<string, string> = {
      'Technology': '#8B5CF6',
      'Energy': '#10B981',
      'Healthcare': '#06B6D4',
      'Fintech': '#F59E0B',
      'Logistics': '#EC4899',
      'Manufacturing': '#EF4444',
      'Retail': '#84CC16',
      'Default': '#6B7280'
    };
    return colors[industry] || colors.Default;
  };

  const getQuadrantInfo = (x: number, y: number) => {
    const centerX = svgWidth / 2;
    const centerY = svgHeight / 2;
    
    if (x > centerX && y < centerY) {
      return { label: 'Priority Leads / Investigate now', color: '#10B981' };
    } else if (x < centerX && y < centerY) {
      return { label: 'Monitor / Opportunistic', color: '#6B7280' };
    } else if (x < centerX && y > centerY) {
      return { label: 'Not a focus', color: '#EF4444' };
    } else {
      return { label: 'Nurture with Support', color: '#F59E0B' };
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Company Portfolio Matrix</CardTitle>
          <Badge variant="outline" className="px-3 py-1">
            {companies.length} Companies
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Click on any company bubble to explore detailed scoring. Positioned by Strategic Fit vs Ability to Execute.
        </p>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col lg:flex-row items-start gap-6">
          {/* SVG Chart */}
          <div className="relative">
            <svg
              width={svgWidth}
              height={svgHeight}
              className="border rounded-lg bg-gradient-to-br from-gray-50/50 to-blue-50/50"
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            >
              {/* Background quadrants */}
              <rect
                x={padding}
                y={padding}
                width={chartWidth / 2}
                height={chartHeight / 2}
                fill="#F3F4F6"
                fillOpacity="0.3"
              />
              <rect
                x={padding + chartWidth / 2}
                y={padding}
                width={chartWidth / 2}
                height={chartHeight / 2}
                fill="#DCFCE7"
                fillOpacity="0.3"
              />
              <rect
                x={padding}
                y={padding + chartHeight / 2}
                width={chartWidth / 2}
                height={chartHeight / 2}
                fill="#FEF2F2"
                fillOpacity="0.3"
              />
              <rect
                x={padding + chartWidth / 2}
                y={padding + chartHeight / 2}
                width={chartWidth / 2}
                height={chartHeight / 2}
                fill="#FFFBEB"
                fillOpacity="0.3"
              />

              {/* Grid lines */}
              {[2, 4, 6, 8].map((value) => (
                <g key={`grid-${value}`}>
                  {/* Vertical grid lines */}
                  <line
                    x1={padding + (value / 10) * chartWidth}
                    y1={padding}
                    x2={padding + (value / 10) * chartWidth}
                    y2={padding + chartHeight}
                    stroke="#E5E7EB"
                    strokeDasharray="2,2"
                  />
                  {/* Horizontal grid lines */}
                  <line
                    x1={padding}
                    y1={padding + chartHeight - (value / 10) * chartHeight}
                    x2={padding + chartWidth}
                    y2={padding + chartHeight - (value / 10) * chartHeight}
                    stroke="#E5E7EB"
                    strokeDasharray="2,2"
                  />
                </g>
              ))}

              {/* Main axes */}
              <line
                x1={padding + chartWidth / 2}
                y1={padding}
                x2={padding + chartWidth / 2}
                y2={padding + chartHeight}
                stroke="#374151"
                strokeWidth="2"
              />
              <line
                x1={padding}
                y1={padding + chartHeight / 2}
                x2={padding + chartWidth}
                y2={padding + chartHeight / 2}
                stroke="#374151"
                strokeWidth="2"
              />

              {/* Axis labels */}
              <text
                x={svgWidth / 2}
                y={svgHeight - 20}
                textAnchor="middle"
                className="text-sm font-medium fill-gray-700"
              >
                Strategic Fit
              </text>
              <text
                x={25}
                y={svgHeight / 2}
                textAnchor="middle"
                className="text-sm font-medium fill-gray-700"
                transform={`rotate(-90, 25, ${svgHeight / 2})`}
              >
                Ability to Execute
              </text>

              {/* Quadrant labels */}
              <text
                x={padding + chartWidth * 0.25}
                y={padding + 20}
                textAnchor="middle"
                className="text-xs font-medium fill-gray-600"
              >
                Monitor / Opportunistic
              </text>
              <text
                x={padding + chartWidth * 0.75}
                y={padding + 20}
                textAnchor="middle"
                className="text-xs font-medium fill-green-600"
              >
                Priority Leads / Investigate now
              </text>
              <text
                x={padding + chartWidth * 0.25}
                y={padding + chartHeight - 10}
                textAnchor="middle"
                className="text-xs font-medium fill-red-600"
              >
                Not a focus
              </text>
              <text
                x={padding + chartWidth * 0.75}
                y={padding + chartHeight - 10}
                textAnchor="middle"
                className="text-xs font-medium fill-yellow-600"
              >
                Nurture with Support
              </text>

              {/* Scale markers */}
              {[0, 2, 4, 6, 8, 10].map((value) => (
                <g key={`marker-${value}`}>
                  {/* X-axis markers */}
                  <text
                    x={padding + (value / 10) * chartWidth}
                    y={padding + chartHeight + 15}
                    textAnchor="middle"
                    className="text-xs fill-gray-500"
                  >
                    {value}
                  </text>
                  {/* Y-axis markers */}
                  <text
                    x={padding - 10}
                    y={padding + chartHeight - (value / 10) * chartHeight + 3}
                    textAnchor="end"
                    className="text-xs fill-gray-500"
                  >
                    {value}
                  </text>
                </g>
              ))}

              {/* Company bubbles */}
              {bubbles.map((bubble, index) => {
                const industryColor = getIndustryColor(bubble.industry);
                return (
                  <g key={bubble.id}>
                    <motion.circle
                      cx={bubble.x}
                      cy={bubble.y}
                      r={bubble.radius}
                      fill={industryColor}
                      fillOpacity={
                        selectedCompany?.id === bubble.id ? 0.9 :
                        hoveredBubble === bubble.id ? 0.8 : 0.6
                      }
                      stroke={selectedCompany?.id === bubble.id ? "#374151" : industryColor}
                      strokeWidth={selectedCompany?.id === bubble.id ? "3" : "2"}
                      className="cursor-pointer transition-all duration-200 drop-shadow-md"
                      onClick={() => handleBubbleClick(bubble)}
                      onMouseEnter={() => setHoveredBubble(bubble.id)}
                      onMouseLeave={() => setHoveredBubble(null)}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.5, delay: index * 0.1, type: "spring" }}
                      whileHover={{ 
                        scale: 1.1,
                        transition: { duration: 0.2 }
                      }}
                      whileTap={{ scale: 0.95 }}
                    />
                    
                    {/* Company name label */}
                    <motion.text
                      x={bubble.x}
                      y={bubble.y - bubble.radius - 8}
                      textAnchor="middle"
                      className="text-xs font-medium fill-gray-700 pointer-events-none"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: hoveredBubble === bubble.id ? 1 : 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      {bubble.name}
                    </motion.text>
                    
                    {/* Score label inside bubble */}
                    <motion.text
                      x={bubble.x}
                      y={bubble.y + 3}
                      textAnchor="middle"
                      className="text-xs font-bold fill-white pointer-events-none"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
                    >
                      {Math.round(bubble.totalScore)}
                    </motion.text>
                  </g>
                );
              })}

              {/* Gradient definitions */}
              <defs>
                {Object.values(['Technology', 'Energy', 'Healthcare', 'Fintech', 'Logistics']).map((industry) => (
                  <linearGradient key={`grad-${industry}`} id={`gradient-${industry}`} x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor={getIndustryColor(industry)} />
                    <stop offset="100%" stopColor={getIndustryColor(industry)} stopOpacity="0.8" />
                  </linearGradient>
                ))}
              </defs>
            </svg>

            {/* Hover tooltip */}
            {hoveredBubble && (
              <motion.div
                className="absolute top-2 right-2 bg-white/95 backdrop-blur-sm p-3 rounded-lg shadow-lg border max-w-64"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.2 }}
              >
                {(() => {
                  const bubble = bubbles.find(b => b.id === hoveredBubble);
                  if (!bubble) return null;
                  const quadrant = getQuadrantInfo(bubble.x, bubble.y);
                  return (
                    <div>
                      <div className="font-medium text-sm" style={{ color: getIndustryColor(bubble.industry) }}>
                        {bubble.name}
                      </div>
                      <div className="text-xs text-muted-foreground mb-2">
                        {bubble.description}
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span>Strategic Fit:</span>
                          <span className="font-medium">{bubble.strategicFit}/10</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span>Ability to Execute:</span>
                          <span className="font-medium">{bubble.abilityToExecute}/10</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span>Total Score:</span>
                          <span className="font-medium" style={{ color: getIndustryColor(bubble.industry) }}>
                            {Math.round(bubble.totalScore * 100) / 100}
                          </span>
                        </div>
                        <div className="pt-1 border-t">
                          <div className="text-xs" style={{ color: quadrant.color }}>
                            {quadrant.label}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </motion.div>
            )}
          </div>

          {/* Legend */}
          <div className="space-y-4 min-w-64">
            <h4 className="font-medium">Industry Legend</h4>
            <div className="space-y-2">
              {Array.from(new Set(companies.map(c => c.industry))).map((industry) => {
                const companiesInIndustry = companies.filter(c => c.industry === industry);
                return (
                  <motion.div
                    key={industry}
                    className="flex items-center justify-between p-2 rounded-lg border hover:bg-muted/50 transition-all"
                    whileHover={{ scale: 1.02 }}
                  >
                    <div className="flex items-center space-x-3">
                      <div
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: getIndustryColor(industry) }}
                      />
                      <div>
                        <div className="text-sm font-medium">{industry}</div>
                        <div className="text-xs text-muted-foreground">
                          {companiesInIndustry.length} companies
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">
                        {Math.round(companiesInIndustry.reduce((sum, c) => sum + c.totalScore, 0) / companiesInIndustry.length)}
                      </div>
                      <div className="text-xs text-muted-foreground">avg</div>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            <div className="pt-4 border-t">
              <h4 className="font-medium mb-2">Chart Guide</h4>
              <div className="text-xs text-muted-foreground space-y-1">
                <p>• Bubble size = Total score</p>
                <p>• X-axis = Strategic fit (0-10)</p>
                <p>• Y-axis = Ability to execute (0-10)</p>
                <p>• Color = Industry category</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { motion } from 'motion/react';
import { 
  Zap, 
  Building2, 
  Cog, 
  DollarSign, 
  Users, 
  Brain,
  Database,
  TrendingUp,
  Trophy,
  Star,
  Flag,
  ArrowUpDown,
  Filter
} from 'lucide-react';

interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  maxScore: number;
  color: string;
}

interface Company {
  id: string;
  name: string;
  description: string;
  industry: string;
  strategicFit: number;
  abilityToExecute: number;
  dimensions: Record<string, number>;
  totalScore: number;
  lastUpdated: string;
}

interface PortfolioDashboardProps {
  companies: Company[];
  dimensions: ScoreDimension[];
  onCompanySelect: (company: Company) => void;
  selectedCompany?: Company | null;
}

export function PortfolioDashboard({ companies, dimensions, onCompanySelect, selectedCompany }: PortfolioDashboardProps) {
  const [hoveredBubble, setHoveredBubble] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'score' | 'name' | 'industry'>('score');
  const [filterIndustry, setFilterIndustry] = useState<string>('all');

  const svgWidth = 600;
  const svgHeight = 400;
  const padding = 60;
  const chartWidth = svgWidth - 2 * padding;
  const chartHeight = svgHeight - 2 * padding;

  // Calculate metric averages
  const getMetricAverages = () => {
    if (companies.length === 0) return {};
    
    const totals = companies.reduce((acc, company) => {
      Object.entries(company.dimensions).forEach(([key, value]) => {
        acc[key] = (acc[key] || 0) + value;
      });
      return acc;
    }, {} as Record<string, number>);

    const averages = Object.entries(totals).reduce((acc, [key, total]) => {
      acc[key] = total / companies.length;
      return acc;
    }, {} as Record<string, number>);

    return averages;
  };

  const metricAverages = getMetricAverages();

  // Get metric icons and labels
  const getMetricInfo = (dimensionId: string) => {
    const info: Record<string, { icon: any, label: string, color: string }> = {
      market_potential: { icon: Zap, label: 'Hydrogen', color: '#8B5CF6' },
      competitive_advantage: { icon: Building2, label: 'Industry', color: '#06B6D4' },
      team_quality: { icon: Cog, label: 'Manufacturing', color: '#10B981' },
      product_fit: { icon: DollarSign, label: 'Financial', color: '#F59E0B' },
      financials: { icon: Users, label: 'Ownership', color: '#EF4444' },
      scalability: { icon: Brain, label: 'IP Activity', color: '#EC4899' },
    };
    return info[dimensionId] || { icon: Database, label: 'Metric', color: '#6B7280' };
  };

  // Calculate portfolio stats
  const getPortfolioStats = () => {
    if (companies.length === 0) return { totalCompanies: 0, avgIPActivity: 0, topPerformer: null, highPerformers: 0 };
    
    const totalCompanies = companies.length;
    const avgIPActivity = metricAverages.scalability || 0;
    const topPerformer = companies.reduce((top, comp) => 
      comp.totalScore > (top?.totalScore || 0) ? comp : top
    );
    const highPerformers = companies.filter(c => c.totalScore >= 80).length;
    
    return { totalCompanies, avgIPActivity, topPerformer, highPerformers };
  };

  const portfolioStats = getPortfolioStats();

  // Get industry colors
  const getIndustryColor = (industry: string) => {
    const colors: Record<string, string> = {
      'Technology': '#8B5CF6',
      'Energy': '#10B981',
      'Healthcare': '#06B6D4',
      'Fintech': '#F59E0B',
      'Logistics': '#EC4899',
      'Manufacturing': '#EF4444',
      'Retail': '#84CC16',
      'Default': '#6B7280'
    };
    return colors[industry] || colors.Default;
  };

  // Position companies on bubble chart
  const getBubbleData = () => {
    return companies.map((company) => {
      const x = padding + (company.strategicFit / 10) * chartWidth;
      const y = padding + chartHeight - (company.abilityToExecute / 10) * chartHeight;
      const radius = 8 + (company.totalScore / 100) * 12;
      
      return {
        ...company,
        x,
        y,
        radius
      };
    });
  };

  const bubbleData = getBubbleData();

  // Sort and filter companies for sidebar
  const getSortedFilteredCompanies = () => {
    let filtered = companies;
    
    if (filterIndustry !== 'all') {
      filtered = companies.filter(c => c.industry === filterIndustry);
    }
    
    return filtered.sort((a, b) => {
      switch (sortBy) {
        case 'score':
          return b.totalScore - a.totalScore;
        case 'name':
          return a.name.localeCompare(b.name);
        case 'industry':
          return a.industry.localeCompare(b.industry);
        default:
          return 0;
      }
    });
  };

  const sortedCompanies = getSortedFilteredCompanies();
  const industries = Array.from(new Set(companies.map(c => c.industry)));

  return (
    <div className="space-y-6">
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {dimensions.slice(0, 6).map((dimension, index) => {
          const avg = metricAverages[dimension.id] || 0;
          const metricInfo = getMetricInfo(dimension.id);
          const MetricIcon = metricInfo.icon;
          
          return (
            <motion.div
              key={dimension.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <Card className={`${index === 0 ? 'ring-2 ring-blue-500/20 bg-blue-50/50' : ''}`}>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="p-2 rounded-lg"
                      style={{ backgroundColor: `${metricInfo.color}20` }}
                    >
                      <MetricIcon 
                        className="h-5 w-5" 
                        style={{ color: metricInfo.color }}
                      />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">{metricInfo.label}</div>
                      <div className="text-2xl font-bold">{avg.toFixed(1)}</div>
                      <div className="text-xs text-muted-foreground">Average Score</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Summary Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-muted-foreground">Total Companies</div>
                <div className="text-3xl font-bold text-blue-600">{portfolioStats.totalCompanies}</div>
                <div className="text-xs text-muted-foreground">in Database</div>
              </div>
              <Database className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-muted-foreground">Avg IP Activity Score</div>
                <div className="text-3xl font-bold text-green-600">{portfolioStats.avgIPActivity.toFixed(1)}</div>
                <div className="text-xs text-muted-foreground">Out of 100</div>
              </div>
              <div className="p-2 bg-gray-200 rounded">
                <div className="w-4 h-4 bg-green-600 rounded"></div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-muted-foreground">Top Performer</div>
                <div className="text-lg font-bold text-purple-600">
                  {portfolioStats.topPerformer?.name || 'N/A'}
                </div>
                <div className="text-xs text-muted-foreground">
                  Score: {portfolioStats.topPerformer?.totalScore.toFixed(1) || '0'}
                </div>
              </div>
              <Trophy className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-muted-foreground">High Performers</div>
                <div className="text-3xl font-bold text-orange-600">{portfolioStats.highPerformers}</div>
                <div className="text-xs text-muted-foreground">Score 80+</div>
              </div>
              <Star className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Area */}
      <div className="grid lg:grid-cols-4 gap-6">
        {/* Bubble Chart */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Strategic Portfolio Matrix</CardTitle>
                <Badge variant="outline">{companies.length} companies</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <svg
                  width={svgWidth}
                  height={svgHeight}
                  className="border rounded-lg bg-gradient-to-br from-gray-50/50 to-blue-50/50 w-full"
                  viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                >
                  {/* Background quadrants */}
                  <rect x={padding} y={padding} width={chartWidth / 2} height={chartHeight / 2} fill="#F3F4F6" fillOpacity="0.3" />
                  <rect x={padding + chartWidth / 2} y={padding} width={chartWidth / 2} height={chartHeight / 2} fill="#DCFCE7" fillOpacity="0.3" />
                  <rect x={padding} y={padding + chartHeight / 2} width={chartWidth / 2} height={chartHeight / 2} fill="#FEF2F2" fillOpacity="0.3" />
                  <rect x={padding + chartWidth / 2} y={padding + chartHeight / 2} width={chartWidth / 2} height={chartHeight / 2} fill="#FFFBEB" fillOpacity="0.3" />

                  {/* Grid lines */}
                  {[2, 4, 6, 8].map((value) => (
                    <g key={`grid-${value}`}>
                      <line
                        x1={padding + (value / 10) * chartWidth}
                        y1={padding}
                        x2={padding + (value / 10) * chartWidth}
                        y2={padding + chartHeight}
                        stroke="#E5E7EB"
                        strokeDasharray="2,2"
                      />
                      <line
                        x1={padding}
                        y1={padding + chartHeight - (value / 10) * chartHeight}
                        x2={padding + chartWidth}
                        y2={padding + chartHeight - (value / 10) * chartHeight}
                        stroke="#E5E7EB"
                        strokeDasharray="2,2"
                      />
                    </g>
                  ))}

                  {/* Main axes */}
                  <line x1={padding + chartWidth / 2} y1={padding} x2={padding + chartWidth / 2} y2={padding + chartHeight} stroke="#374151" strokeWidth="2" />
                  <line x1={padding} y1={padding + chartHeight / 2} x2={padding + chartWidth} y2={padding + chartHeight / 2} stroke="#374151" strokeWidth="2" />

                  {/* Quadrant labels */}
                  <text x={padding + chartWidth * 0.25} y={padding + 20} textAnchor="middle" className="text-xs font-medium fill-gray-600">
                    Monitor / Opportunistic
                  </text>
                  <text x={padding + chartWidth * 0.75} y={padding + 20} textAnchor="middle" className="text-xs font-medium fill-green-600">
                    Priority leads (Investigate now)
                  </text>
                  <text x={padding + chartWidth * 0.25} y={padding + chartHeight - 10} textAnchor="middle" className="text-xs font-medium fill-red-600">
                    Not a focus
                  </text>
                  <text x={padding + chartWidth * 0.75} y={padding + chartHeight - 10} textAnchor="middle" className="text-xs font-medium fill-yellow-600">
                    Nurture with Support
                  </text>

                  {/* Axis labels */}
                  <text x={svgWidth / 2} y={svgHeight - 10} textAnchor="middle" className="text-sm font-medium fill-gray-700">
                    Strategic Fit
                  </text>
                  <text x={20} y={svgHeight / 2} textAnchor="middle" className="text-sm font-medium fill-gray-700" transform={`rotate(-90, 20, ${svgHeight / 2})`}>
                    Ability to Execute
                  </text>

                  {/* Company bubbles */}
                  {bubbleData.map((bubble, index) => (
                    <motion.circle
                      key={bubble.id}
                      cx={bubble.x}
                      cy={bubble.y}
                      r={bubble.radius}
                      fill={getIndustryColor(bubble.industry)}
                      fillOpacity={selectedCompany?.id === bubble.id ? 0.9 : hoveredBubble === bubble.id ? 0.8 : 0.6}
                      stroke={selectedCompany?.id === bubble.id ? "#374151" : getIndustryColor(bubble.industry)}
                      strokeWidth={selectedCompany?.id === bubble.id ? "2" : "1"}
                      className="cursor-pointer transition-all duration-200"
                      onClick={() => onCompanySelect(bubble)}
                      onMouseEnter={() => setHoveredBubble(bubble.id)}
                      onMouseLeave={() => setHoveredBubble(null)}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.02 }}
                    />
                  ))}

                  {/* Scale markers */}
                  {[0, 2, 4, 6, 8, 10].map((value) => (
                    <g key={`marker-${value}`}>
                      <text x={padding + (value / 10) * chartWidth} y={padding + chartHeight + 15} textAnchor="middle" className="text-xs fill-gray-500">
                        {value}
                      </text>
                      <text x={padding - 10} y={padding + chartHeight - (value / 10) * chartHeight + 3} textAnchor="end" className="text-xs fill-gray-500">
                        {value}
                      </text>
                    </g>
                  ))}
                </svg>

                {/* Hover tooltip */}
                {hoveredBubble && (
                  <motion.div
                    className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm p-3 rounded-lg shadow-lg border max-w-64 z-10"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                  >
                    {(() => {
                      const bubble = bubbleData.find(b => b.id === hoveredBubble);
                      if (!bubble) return null;
                      return (
                        <div>
                          <div className="font-medium text-sm" style={{ color: getIndustryColor(bubble.industry) }}>
                            {bubble.name}
                          </div>
                          <div className="text-xs text-muted-foreground mb-2">{bubble.description}</div>
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span>Strategic Fit:</span>
                              <span className="font-medium">{bubble.strategicFit}/10</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span>Execution:</span>
                              <span className="font-medium">{bubble.abilityToExecute}/10</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span>Total Score:</span>
                              <span className="font-medium">{bubble.totalScore.toFixed(1)}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </motion.div>
                )}
              </div>

              {/* Footer attribution */}
              <div className="mt-4 text-right">
                <div className="text-xs text-muted-foreground italic">
                  "How aligned they are with our value proposition"
                </div>
                <div className="text-xs text-muted-foreground">
                  Industry fit, IP strategy, Manufacturing Capability
                </div>
                <div className="text-xs text-muted-foreground">
                  Source: due diligence (or manufacturing capability)
                </div>
                <div className="mt-1">
                  <span className="text-orange-500 font-bold text-sm">ceres</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Company List Sidebar */}
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Companies</CardTitle>
                <Button variant="ghost" size="sm">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Button
                  variant={sortBy === 'score' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setSortBy('score')}
                  className="text-xs"
                >
                  Score
                </Button>
                <Button
                  variant={sortBy === 'name' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setSortBy('name')}
                  className="text-xs"
                >
                  Name
                </Button>
                <ArrowUpDown className="h-3 w-3 text-muted-foreground" />
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                <div className="space-y-1 p-3">
                  {sortedCompanies.map((company) => (
                    <motion.div
                      key={company.id}
                      className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-all hover:bg-muted/50 ${
                        selectedCompany?.id === company.id ? 'bg-primary/10 border-primary' : ''
                      }`}
                      onClick={() => onCompanySelect(company)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="flex items-center space-x-3 flex-1 min-w-0">
                        <div className="flex items-center space-x-2">
                          <Flag className="h-3 w-3 text-blue-600" />
                          <Badge variant="secondary" className="text-xs px-1 py-0">
                            Market
                          </Badge>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium truncate">{company.name}</div>
                          <div className="flex items-center space-x-2">
                            <div className="w-16 bg-purple-600 h-2 rounded-full"></div>
                            <span className="text-xs text-muted-foreground">100</span>
                          </div>
                          <div className="flex items-center space-x-2 mt-1">
                            <div className="w-6 bg-orange-400 h-1 rounded-full"></div>
                            <span className="text-xs text-muted-foreground">35</span>
                            <span className="text-xs text-orange-600 font-medium">Priority targets</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
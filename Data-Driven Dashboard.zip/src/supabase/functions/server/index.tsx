import { Hono } from "npm:hono@4.6.12";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2.46.1";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Setup middleware
app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['*'],
}));
app.use('*', logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Types for company scoring framework
interface ScoreDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
  maxScore: number;
  color: string;
}

interface Company {
  id: string;
  name: string;
  description: string;
  industry: string;
  strategicFit: number; // 0-10 scale
  abilityToExecute: number; // 0-10 scale
  dimensions: Record<string, number>;
  totalScore: number;
  lastUpdated: string;
}

interface ScoreEntry {
  id: string;
  companyId: string;
  userId: string;
  timestamp: string;
  dimensions: Record<string, number>;
  totalScore: number;
  notes?: string;
}

// Default 6 dimensions for company scoring
const defaultDimensions: ScoreDimension[] = [
  {
    id: 'market_potential',
    name: 'Market Potential',
    description: 'Size and growth potential of target market',
    weight: 0.20,
    maxScore: 100,
    color: '#8B5CF6'
  },
  {
    id: 'competitive_advantage',
    name: 'Competitive Advantage',
    description: 'Unique value proposition and differentiation',
    weight: 0.18,
    maxScore: 100,
    color: '#06B6D4'
  },
  {
    id: 'team_quality',
    name: 'Team Quality',
    description: 'Leadership and team capabilities',
    weight: 0.15,
    maxScore: 100,
    color: '#10B981'
  },
  {
    id: 'product_fit',
    name: 'Product-Market Fit',
    description: 'Product alignment with market needs',
    weight: 0.17,
    maxScore: 100,
    color: '#F59E0B'
  },
  {
    id: 'financials',
    name: 'Financial Health',
    description: 'Revenue, profitability, and financial stability',
    weight: 0.15,
    maxScore: 100,
    color: '#EF4444'
  },
  {
    id: 'scalability',
    name: 'Scalability',
    description: 'Ability to scale operations and technology',
    weight: 0.15,
    maxScore: 100,
    color: '#EC4899'
  }
];

// Sample companies data - 100 companies for comprehensive portfolio
const defaultCompanies: Company[] = [
  // Top performers (High Strategic Fit, High Execution)
  {
    id: 'company_1',
    name: 'Bloom Energy Corporation',
    description: 'Fuel cell power generation',
    industry: 'Energy',
    strategicFit: 8.65,
    abilityToExecute: 8.2,
    dimensions: { market_potential: 92, competitive_advantage: 85, team_quality: 88, product_fit: 90, financials: 82, scalability: 87 },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'company_2',
    name: 'Hydrogen Power Systems',
    description: 'Industrial hydrogen solutions',
    industry: 'Energy',
    strategicFit: 8.8,
    abilityToExecute: 7.9,
    dimensions: { market_potential: 89, competitive_advantage: 88, team_quality: 81, product_fit: 92, financials: 78, scalability: 85 },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'company_3',
    name: 'Advanced Materials Corp',
    description: 'Catalyst manufacturing',
    industry: 'Manufacturing',
    strategicFit: 8.2,
    abilityToExecute: 8.5,
    dimensions: { market_potential: 85, competitive_advantage: 82, team_quality: 89, product_fit: 88, financials: 85, scalability: 83 },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'company_4',
    name: 'CleanTech Industries',
    description: 'Green manufacturing processes',
    industry: 'Technology',
    strategicFit: 7.8,
    abilityToExecute: 8.1,
    dimensions: { market_potential: 88, competitive_advantage: 78, team_quality: 84, product_fit: 82, financials: 80, scalability: 86 },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  },
  
  // Priority Leads (High Strategic Fit, Medium-High Execution)
  {
    id: 'company_5',
    name: 'FuelCell Energy Inc',
    description: 'Stationary fuel cell systems',
    industry: 'Energy',
    strategicFit: 8.4,
    abilityToExecute: 7.2,
    dimensions: { market_potential: 86, competitive_advantage: 84, team_quality: 75, product_fit: 88, financials: 70, scalability: 82 },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'company_6',
    name: 'Ballard Power Systems',
    description: 'Fuel cell technology',
    industry: 'Technology',
    strategicFit: 8.1,
    abilityToExecute: 7.5,
    dimensions: { market_potential: 84, competitive_advantage: 81, team_quality: 78, product_fit: 85, financials: 72, scalability: 80 },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  },
  
  // Medium performers distributed across quadrants
  {
    id: 'company_7',
    name: 'PowerGen Solutions',
    description: 'Distributed energy systems',
    industry: 'Energy',
    strategicFit: 6.8,
    abilityToExecute: 7.8,
    dimensions: { market_potential: 75, competitive_advantage: 68, team_quality: 82, product_fit: 70, financials: 78, scalability: 74 },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'company_8',
    name: 'Industrial Gas Corp',
    description: 'Gas processing equipment',
    industry: 'Manufacturing',
    strategicFit: 5.9,
    abilityToExecute: 6.8,
    dimensions: { market_potential: 68, competitive_advantage: 59, team_quality: 72, product_fit: 65, financials: 68, scalability: 66 },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'company_9',
    name: 'EnergyTech Ventures',
    description: 'Energy storage systems',
    industry: 'Technology',
    strategicFit: 7.2,
    abilityToExecute: 6.1,
    dimensions: { market_potential: 78, competitive_advantage: 72, team_quality: 62, product_fit: 75, financials: 58, scalability: 71 },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'company_10',
    name: 'Green Manufacturing Ltd',
    description: 'Sustainable production',
    industry: 'Manufacturing',
    strategicFit: 6.5,
    abilityToExecute: 7.4,
    dimensions: { market_potential: 72, competitive_advantage: 65, team_quality: 76, product_fit: 68, financials: 74, scalability: 69 },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  }
];

// Generate additional companies to reach 100 total
for (let i = 11; i <= 100; i++) {
  const industries = ['Technology', 'Energy', 'Manufacturing', 'Healthcare', 'Fintech'];
  const industry = industries[Math.floor(Math.random() * industries.length)];
  
  // Generate strategic fit and execution scores with some clustering
  const strategicFit = Math.random() * 10;
  const abilityToExecute = Math.random() * 10;
  
  // Generate dimension scores around some realistic ranges
  const baseScore = 40 + Math.random() * 50; // 40-90 range
  const variance = 15;
  
  const company: Company = {
    id: `company_${i}`,
    name: `Company ${String.fromCharCode(65 + ((i - 11) % 26))}${Math.floor((i - 11) / 26) + 1}`,
    description: `${industry} company focused on innovation`,
    industry,
    strategicFit: Math.round(strategicFit * 10) / 10,
    abilityToExecute: Math.round(abilityToExecute * 10) / 10,
    dimensions: {
      market_potential: Math.max(10, Math.min(100, Math.round(baseScore + (Math.random() - 0.5) * variance))),
      competitive_advantage: Math.max(10, Math.min(100, Math.round(baseScore + (Math.random() - 0.5) * variance))),
      team_quality: Math.max(10, Math.min(100, Math.round(baseScore + (Math.random() - 0.5) * variance))),
      product_fit: Math.max(10, Math.min(100, Math.round(baseScore + (Math.random() - 0.5) * variance))),
      financials: Math.max(10, Math.min(100, Math.round(baseScore + (Math.random() - 0.5) * variance))),
      scalability: Math.max(10, Math.min(100, Math.round(baseScore + (Math.random() - 0.5) * variance)))
    },
    totalScore: 0,
    lastUpdated: new Date().toISOString()
  };
  
  defaultCompanies.push(company);
}

// Calculate total scores for companies
defaultCompanies.forEach(company => {
  company.totalScore = defaultDimensions.reduce((sum, dim) => {
    return sum + (company.dimensions[dim.id] * dim.weight);
  }, 0);
});

// Initialize default data if it doesn't exist
app.get('/make-server-faa13dcb/init', async (c) => {
  try {
    const existingDimensions = await kv.get('scoring_dimensions');
    const existingCompanies = await kv.get('companies');
    
    if (!existingDimensions) {
      await kv.set('scoring_dimensions', defaultDimensions);
      console.log('Initialized default scoring dimensions');
    }
    
    if (!existingCompanies) {
      await kv.set('companies', defaultCompanies);
      console.log('Initialized default companies');
    }
    
    return c.json({ success: true, message: 'Company scoring framework initialized' });
  } catch (error) {
    console.error('Error initializing scoring framework:', error);
    return c.json({ error: 'Failed to initialize scoring framework' }, 500);
  }
});

// Get all scoring dimensions
app.get('/make-server-faa13dcb/dimensions', async (c) => {
  try {
    const dimensions = await kv.get('scoring_dimensions') || defaultDimensions;
    return c.json(dimensions);
  } catch (error) {
    console.error('Error fetching dimensions:', error);
    return c.json({ error: 'Failed to fetch dimensions' }, 500);
  }
});

// Get all companies
app.get('/make-server-faa13dcb/companies', async (c) => {
  try {
    const companies = await kv.get('companies') || defaultCompanies;
    return c.json(companies);
  } catch (error) {
    console.error('Error fetching companies:', error);
    return c.json({ error: 'Failed to fetch companies' }, 500);
  }
});

// Get a specific company
app.get('/make-server-faa13dcb/companies/:id', async (c) => {
  try {
    const companyId = c.req.param('id');
    const companies = await kv.get('companies') || defaultCompanies;
    const company = companies.find((comp: Company) => comp.id === companyId);
    
    if (!company) {
      return c.json({ error: 'Company not found' }, 404);
    }
    
    return c.json(company);
  } catch (error) {
    console.error('Error fetching company:', error);
    return c.json({ error: 'Failed to fetch company' }, 500);
  }
});

// Update company dimension scores
app.post('/make-server-faa13dcb/companies/:id/dimensions/update', async (c) => {
  try {
    const companyId = c.req.param('id');
    const { dimensionId, score } = await c.req.json();
    
    const companies = await kv.get('companies') || defaultCompanies;
    const dimensions = await kv.get('scoring_dimensions') || defaultDimensions;
    
    const updatedCompanies = companies.map((comp: Company) => {
      if (comp.id === companyId) {
        const updatedDimensions = { ...comp.dimensions, [dimensionId]: score };
        const totalScore = dimensions.reduce((sum: number, dim: ScoreDimension) => {
          return sum + (updatedDimensions[dim.id] * dim.weight);
        }, 0);
        
        return {
          ...comp,
          dimensions: updatedDimensions,
          totalScore: Math.round(totalScore * 100) / 100,
          lastUpdated: new Date().toISOString()
        };
      }
      return comp;
    });
    
    await kv.set('companies', updatedCompanies);
    
    const updatedCompany = updatedCompanies.find((comp: Company) => comp.id === companyId);
    return c.json({ success: true, company: updatedCompany });
  } catch (error) {
    console.error('Error updating company dimension score:', error);
    return c.json({ error: 'Failed to update company dimension score' }, 500);
  }
});

// Submit a complete score entry for a company
app.post('/make-server-faa13dcb/companies/:id/scores/submit', async (c) => {
  try {
    const companyId = c.req.param('id');
    const { userId, dimensions, notes } = await c.req.json();
    
    // Calculate weighted total score
    const scoringDimensions = await kv.get('scoring_dimensions') || defaultDimensions;
    let totalScore = 0;
    
    for (const [dimId, score] of Object.entries(dimensions)) {
      const dimension = scoringDimensions.find((d: ScoreDimension) => d.id === dimId);
      if (dimension) {
        totalScore += (score as number) * dimension.weight;
      }
    }
    
    const scoreEntry: ScoreEntry = {
      id: `score_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      companyId,
      userId,
      timestamp: new Date().toISOString(),
      dimensions,
      totalScore: Math.round(totalScore * 100) / 100,
      notes
    };
    
    // Store the score entry
    await kv.set(`score_entry_${scoreEntry.id}`, scoreEntry);
    
    // Update company scores
    const companies = await kv.get('companies') || defaultCompanies;
    const updatedCompanies = companies.map((comp: Company) => {
      if (comp.id === companyId) {
        return {
          ...comp,
          dimensions,
          totalScore: Math.round(totalScore * 100) / 100,
          lastUpdated: new Date().toISOString()
        };
      }
      return comp;
    });
    await kv.set('companies', updatedCompanies);
    
    return c.json({ success: true, scoreEntry, totalScore });
  } catch (error) {
    console.error('Error submitting score entry:', error);
    return c.json({ error: 'Failed to submit score entry' }, 500);
  }
});

// Get score history
app.get('/make-server-faa13dcb/scores/history', async (c) => {
  try {
    const userId = c.req.query('userId');
    const companyId = c.req.query('companyId');
    const scores = await kv.getByPrefix('score_entry_');
    
    let filteredScores = scores;
    if (userId) {
      filteredScores = scores.filter((entry: any) => entry.value.userId === userId);
    }
    if (companyId) {
      filteredScores = filteredScores.filter((entry: any) => entry.value.companyId === companyId);
    }
    
    // Sort by timestamp descending
    filteredScores.sort((a: any, b: any) => 
      new Date(b.value.timestamp).getTime() - new Date(a.value.timestamp).getTime()
    );
    
    return c.json(filteredScores.map((entry: any) => entry.value));
  } catch (error) {
    console.error('Error fetching score history:', error);
    return c.json({ error: 'Failed to fetch score history' }, 500);
  }
});

// Get analytics data
app.get('/make-server-faa13dcb/analytics', async (c) => {
  try {
    const scores = await kv.getByPrefix('score_entry_');
    const dimensions = await kv.get('scoring_dimensions') || defaultDimensions;
    
    if (scores.length === 0) {
      return c.json({
        totalEntries: 0,
        averageScore: 0,
        dimensionAverages: {},
        recentTrend: [],
        topPerformers: []
      });
    }
    
    const scoreEntries = scores.map((entry: any) => entry.value);
    
    // Calculate averages
    const totalAverage = scoreEntries.reduce((sum: number, entry: ScoreEntry) => 
      sum + entry.totalScore, 0) / scoreEntries.length;
    
    const dimensionAverages: Record<string, number> = {};
    dimensions.forEach((dim: ScoreDimension) => {
      const dimScores = scoreEntries
        .map((entry: ScoreEntry) => entry.dimensions[dim.id])
        .filter(score => score !== undefined);
      
      if (dimScores.length > 0) {
        dimensionAverages[dim.id] = dimScores.reduce((sum, score) => sum + score, 0) / dimScores.length;
      }
    });
    
    // Recent trend (last 10 entries)
    const recentTrend = scoreEntries
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
      .slice(-10)
      .map((entry: ScoreEntry) => ({
        timestamp: entry.timestamp,
        score: entry.totalScore
      }));
    
    return c.json({
      totalEntries: scoreEntries.length,
      averageScore: Math.round(totalAverage * 100) / 100,
      dimensionAverages,
      recentTrend,
      topPerformers: scoreEntries
        .sort((a, b) => b.totalScore - a.totalScore)
        .slice(0, 5)
        .map((entry: ScoreEntry) => ({
          id: entry.id,
          userId: entry.userId,
          score: entry.totalScore,
          timestamp: entry.timestamp
        }))
    });
  } catch (error) {
    console.error('Error fetching analytics:', error);
    return c.json({ error: 'Failed to fetch analytics' }, 500);
  }
});

// Reset all data (for demo purposes)
app.post('/make-server-faa13dcb/reset', async (c) => {
  try {
    // Reset dimensions to default
    await kv.set('scoring_dimensions', defaultDimensions);
    
    // Reset companies to default
    await kv.set('companies', defaultCompanies);
    
    // Clear all score entries
    const scores = await kv.getByPrefix('score_entry_');
    for (const score of scores) {
      await kv.del(score.key);
    }
    
    return c.json({ success: true, message: 'All data reset successfully' });
  } catch (error) {
    console.error('Error resetting data:', error);
    return c.json({ error: 'Failed to reset data' }, 500);
  }
});

Deno.serve(app.fetch);